### WraithHunter

Is the author of the original [Quarry Works!](https://mods.vintagestory.at/show/mod/44) mod for 1.14.<br/>
Stone Quarry has come a long way since then, but without him it would never exist.

### DArkHekRoMaNT

The author of [StoneQuarry](https://github.com/DArkHekRoMaNT/StoneQuarry), amonst other mods like [PlayerCorpse](https://github.com/DArkHekRoMaNT/PlayerCorpse), [CommonLib](https://github.com/DArkHekRoMaNT/CommonLib), and many others. They have worked on this mod since 2021 which I can only imagine took a monumental amount of effort and time.

### Translators
- makoto_hino - Japanese translator
- Mayadzuko - Russian translator (guides)
- Aimli - Chinese translator
- purple8cloud - Korean translator
- All translators from [Vintage Story Mods](https://crowdin.com/project/vintage-story-mods) Crowdin

